#ifndef mux_2x1_1_H_INCLUDED
#define mux_2x1_1_H_INCLUDED

int mux(int a, int b, int Sel){

  FILE *arquivo;
  arquivo = fopen("mux_2x1_1/Simulation/ModelSim/mux_2x1_1.tv", "a");

  //fprintf(arquivo, "//MUX\n//Sel_Saida\n");
  fprintf(arquivo, "%d_%d_%d_", Sel,a,b);

  if(!Sel){
        fprintf(arquivo, "%d\n", a);
        return a;
  }
  else{
        fprintf(arquivo, "%d\n", b);
        return b;
  }
  fclose(arquivo);
}
#endif
