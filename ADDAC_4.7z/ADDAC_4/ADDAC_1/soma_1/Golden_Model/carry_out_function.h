#ifndef CARRY_OUT_FUNCTION_H_INCLUDED
#define CARRY_OUT_FUNCTION_H_INCLUDED

int carry_out_function(int soma){
    if(soma>1){
        return 1;
    }
    else return 0;
}
#endif
