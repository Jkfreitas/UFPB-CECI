#ifndef inv_1_H_INCLUDED
#define inv_1_H_INCLUDED

#include <stdbool.h>

int inversor(int a){

  FILE *arquivo;
  int aux=!a;

  arquivo = fopen("inv_1/Simulation/ModelSim/inv_1.tv", "a");
  //fprintf(arquivo, "//Inversor\n//Entrada_Saida\n");
  fprintf(arquivo, "%d_%d\n", a, aux);
  return aux;
  fclose(arquivo);
}
#endif
